package com.techcompare.backend.service;

import com.google.genai.Client;
import com.google.genai.types.GenerateContentResponse;
import org.springframework.stereotype.Service;

@Service
public class GeminiService {

    private final Client client;

    public GeminiService() {
        String apiKey = System.getenv("GEMINI_API_KEY");
        if (apiKey == null || apiKey.isBlank()) {
            throw new IllegalStateException(
                    "GEMINI_API_KEY is not set. Start the backend in the same PowerShell where GEMINI_API_KEY is defined."
            );
        }
        this.client = Client.builder().apiKey(apiKey).build();
    }

    public String askGemini(String prompt) {
        if (prompt == null || prompt.isBlank()) {
            throw new IllegalArgumentException("AI prompt is empty.");
        }

        GenerateContentResponse response = client.models.generateContent(
                "gemini-3.6-flash",
                prompt,
                null
        );

        String text = response == null ? null : response.text();
        if (text == null || text.isBlank()) {
            throw new IllegalStateException("Gemini returned an empty response.");
        }
        return text.trim();
    }
}
