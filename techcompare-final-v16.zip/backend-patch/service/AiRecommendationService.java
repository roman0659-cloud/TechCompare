package com.techcompare.backend.service;

import com.techcompare.backend.dto.AiRecommendationRequest;
import com.techcompare.backend.dto.AiRecommendationResponse;
import com.techcompare.backend.dto.ComparisonResponse;
import com.techcompare.backend.dto.PreferenceWeights;
import com.techcompare.backend.dto.DeviceComparisonDTO;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Map;

@Service
public class AiRecommendationService {

    private final ComparisonService comparisonService;
    private final GeminiService geminiService;

    public AiRecommendationService(
            ComparisonService comparisonService,
            GeminiService geminiService) {

        this.comparisonService = comparisonService;
        this.geminiService = geminiService;
    }

    public AiRecommendationResponse generateRecommendation(
            AiRecommendationRequest request) {

        // Calculate the same scores used by the normal comparison endpoint
        com.techcompare.backend.dto.ComparisonRequest comparisonRequest =
                new com.techcompare.backend.dto.ComparisonRequest();

        comparisonRequest.setDeviceIds(request.getDeviceIds());
        comparisonRequest.setWeights(request.getWeights());

        ComparisonResponse comparison =
                comparisonService.compareDevices(comparisonRequest);

        String prompt = buildPrompt(comparison);

        String recommendation =
                geminiService.askGemini(prompt);

        return new AiRecommendationResponse(recommendation);
    }

    private String buildPrompt(ComparisonResponse comparison) {

        StringBuilder prompt = new StringBuilder();

        prompt.append("""
        You are the AI assistant for TechCompare, a device comparison
        platform.

        Analyze ONLY the device data provided below.
        Do not invent specifications, benchmarks, prices, features,
        or other information that is not provided.

        The devices have already been compared by the TechCompare
        scoring system. Use the provided category scores and
        personalized overall scores when explaining the result.

        Give a concise, practical recommendation based on ALL three
        preference weights shown below. Do not silently replace the
        user's custom mix with a single default goal. If one category
        has 0%, it must not influence the recommendation. If two or
        three categories have non-zero weights, discuss their trade-offs
        in proportion to those weights.

        Focus only on differences that are relevant to the user's
        actual weights and selected devices. Do not repeat specifications unnecessarily.

        Keep the response short and easy to understand.

        User preference weights:
        """);

        PreferenceWeights weights = comparison.getWeights();

        prompt.append("\nGaming: ")
                .append(weights.getGaming())
                .append("%");

        prompt.append("\nPhotography: ")
                .append(weights.getPhotography())
                .append("%");

        prompt.append("\nDaily Use: ")
                .append(weights.getDailyUse())
                .append("%");

        prompt.append("\n\nDevices:\n");

        List<DeviceComparisonDTO> devices =
                comparison.getDevices();

        Map<Long, Double> gamingScores =
                comparison.getGamingScores();

        Map<Long, Double> photographyScores =
                comparison.getPhotographyScores();

        Map<Long, Double> dailyUseScores =
                comparison.getDailyUseScores();

        Map<Long, Double> overallScores =
                comparison.getOverallScores();

        for (DeviceComparisonDTO device : devices) {

            Long id = device.getId();

            prompt.append("\n--- Device ---\n");

            prompt.append("ID: ")
                    .append(id)
                    .append("\n");

            prompt.append("Brand: ")
                    .append(device.getBrand())
                    .append("\n");

            prompt.append("Model: ")
                    .append(device.getModelName())
                    .append("\n");

            prompt.append("Price: $")
                    .append(device.getPriceUsd())
                    .append("\n");

            prompt.append("RAM: ")
                    .append(device.getRamGb())
                    .append(" GB ")
                    .append(device.getRamType())
                    .append("\n");

            prompt.append("Storage: ")
                    .append(device.getStorageGb())
                    .append(" GB ")
                    .append(device.getStorageType())
                    .append("\n");

            prompt.append("CPU: ")
                    .append(device.getCpuName())
                    .append("\n");

            prompt.append("GPU: ")
                    .append(device.getGpuName())
                    .append("\n");

            prompt.append("Display: ")
                    .append(device.getDisplayResolution())
                    .append(", ")
                    .append(device.getDisplayRefreshRate())
                    .append(" Hz")
                    .append("\n");

            prompt.append("Battery: ")
                    .append(device.getBatteryMah())
                    .append(" mAh")
                    .append("\n");

            prompt.append("Charging: ")
                    .append(device.getChargingW())
                    .append(" W")
                    .append("\n");

            prompt.append("Main camera sensor: ")
                    .append(device.getMainSensorSize())
                    .append("\n");

            prompt.append("Main camera aperture: ")
                    .append(device.getMainAperture())
                    .append("\n");

            prompt.append("Optical zoom: ")
                    .append(device.getOpticalZoom())
                    .append("\n");

            prompt.append("Video: ")
                    .append(device.getVideoCapabilities())
                    .append("\n");

            prompt.append("Gaming score: ")
                    .append(gamingScores.get(id))
                    .append("\n");

            prompt.append("Photography score: ")
                    .append(photographyScores.get(id))
                    .append("\n");

            prompt.append("Daily use score: ")
                    .append(dailyUseScores.get(id))
                    .append("\n");

            prompt.append("Personalized overall score: ")
                    .append(overallScores.get(id))
                    .append("\n");
        }

        prompt.append("""
        
        Based only on this information, provide a concise recommendation.

        Requirements:
        - Maximum 160 words.
        - Do not use section headings.
        - Do not list every specification.
        - Consider every non-zero preference weight from the screen.
        - Explain the trade-off between the selected categories instead of
          repeating the same single recommendation for every configuration.
        - Explain why the recommended device matches the full preference mix.
        - You may mention one alternative if it offers a meaningful advantage,
          such as a lower price or stronger score in a secondary weighted category.
        - Do not make claims that are not supported by the provided data.
        """);

        return prompt.toString();
    }
}